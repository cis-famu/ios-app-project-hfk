//
//  ViewController.swift
//  NutriPal
//
//  Created by Faith Stanio on 4/19/23.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func Homepage (_ sender:Any) {
        performSegue(withIdentifier: "Dashboard", sender: nil)
    }

    @IBAction func Signup (_ sender:Any) {
        performSegue(withIdentifier: "Signup", sender: nil)
    }
    
}

